Copy YADD_MMSI_SHIP-Download.exe to a folder with write access on your harddisk.
Open yaddpath.txt and specifify the full path to YaDD.exe.
For standard installations the path is C:\Program Files (x86)\YaDD\YaDD.exe
Please check if the path is correct for your installation and change it when necessary.
This step is important to determin the correct download folder:
In standard installations YADD_MMSI_SHIP.TXT and YADD_MMSI_COAST.TXT must be written to a VirtualStore directory.
For other installations YADD_MMSI_SHIP.TXT and YADD_MMSI_COAST.TXT must be written to the application directory.
This is a Windows security restriction. Thus the full path to YaDD.exe is important.

YaDD must have been installed and run at least once in order to provide the corresponding user directory.

YaDD.exe must not run when YADD_MMSI_SHIP-Download.exe is started! YaDD.exe overwrites the files
YADD_MMSI_SHIP.TXT and YADD_MMSI_COAST.TXT from its own memory when closed. Thus: Always close YaDD.exe before calling
YADD_MMSI_SHIP-Download.exe! Do not run both applications in parallel!

YADD_MMSI_SHIP-Download.exe automatically starts YaDD.exe 3 seconds after a successful download.

Verification:
After YADD_MMSI_SHIP-Download.exe has completed its task click on the tab "Coast Stations" in YaDD.exe.
Next to "Ship names on file" the same number of ships should appear as YADD_MMSI_SHIP-Download.exe
has reported before. Also watch the VERSION number on top of the coast stations table.